package com.example.strokeapp2;


public class Ipsum {

    static String[] Headlines = {
            "HELP",
            "PREVENTATIVE INFORMATION"
    };

    static String[] Articles = {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F"
    };
}
